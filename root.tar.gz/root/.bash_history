history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
hostnamectl set-hostname TPServer
hostname
cat /etc/hostname 
reboot
hostname
lsb_release -a
ping -c 4 8.8.8.8
ping -c 4 deb.debian.org
cat /etc/sources.list
cat /etc/os-release
ping -c 4 8.8.8.8
ping -c 4 deb.debian.org
cat /etc/apt//sources.list
apt update
/etc/apt//sources.list
/etc/apt//sources.list
nano /etc/apt//sources.list
nano /etc/apt/sources.list
nano /etc/apt/sources.list
vi /etc/apt/sources.list
cat /etc/apt//sources.list
apt update
apt upgrade -y
/etc/apt//sources.list
vi /etc/apt/sources.list
cat /etc/apt//sources.list
apt update
apt full-upgrade -y
apt autoremove -y
reboot
echo prueba
ls -ld /root/.ssh
ls -l /root/.ssh/authorized_keys 
chown -R root:root /root/.ssh
systemctl is-active ssh
hostname -I
ip -4 addr show
poweroff
hostname
exit
apt update
apt install apache2 php libapache2-mod-php php-mysql -y
systemctl is-active apache2
apache2 -v
php -v
ss -tlnp | grep ':80'
curl -I http://127.0.0.1
exit
systemctl is-active ssh
poweroff
systemctl is-active apache2
find /root -maxdepth 5 \( -iname 'index.php' -o -iname 'logo.png' -o -iname 'db.sql' -o -iname '*Material*' \) -print
cd /root
ls -lh Material_Adicional_TPVMCA.tar.gz
tar -tzf Material_Adicional_TPVMCA.tar.gz
tar -xzvf Material_Adicional_TPVMCA.tar.gz
find /root -maxdepth 5 \( -iname 'index.php' -o -iname 'logo.png' -o -iname 'db.sql' \) -print
ls -l /var/www/html
mv /var/www/html/index.html /var/www/html/index.html.bak
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -l /var/www/html
chown -R www-data:www-data /var/www/html
find /var/www/html -type d -exec chmod 755 {} \;
find /var/www/html -type f -exec chmod 644 {} \;
systemctl restart apache2
systemctl is-active apache2
curl -I http://127.0.0.1
tail -n 40 /var/log/apache2/error.log
php -l /var/www/html/index.php
grep -Ei 'mysqli|pdo|host|user|pass|database|dbname|mysql' /var/www/html/index.php
apt install mariadb-server -y
systemctl is-active mariadb
systemctl enable mariadb
mariadb -e "SELECT VERSION();"
mariadb -e "CREATE DATABASE IF NOT EXISTS ingenieria CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mariadb -e "CREATE USER IF NOT EXISTS 'lcars'@'localhost' IDENTIFIED BY 'NCC1701D';"
mariadb -e "GRANT ALL PRIVILEGES ON ingenieria.* TO 'lcars'@'localhost';"
mariadb -e "FLUSH PRIVILEGES;"
mariadb ingenieria < /root/Material_Adicional_TPVMCA/db.sql
mariadb -u lcars -pNCC1701D -e "SHOW DATABASES;"
mariadb -u lcars -pNCC1701D ingenieria -e "SHOW TABLES;"
mariadb -e "DROP DATABASE IF EXISTS ingenieria;"
mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb -e "GRANT ALL PRIVILEGES ON ingenieria.* TO 'lcars'@'localhost';"
mariadb -e "FLUSH PRIVILEGES;"
mariadb -u lcars -pNCC1701D ingenieria -e "SHOW TABLES;"
mariadb -u lcars -pNCC1701D ingenieria -e "SELECT COUNT(*) AS cantidad_alumnos FROM alumnos;"
mariadb -u lcars -pNCC1701D ingenieria -e "SELECT COUNT(*) AS cantidad_modulos FROM modulos;"
mariadb -u lcars -pNCC1701D ingenieria -e "SELECT COUNT(*) AS cantidad_notas FROM notas;"
systemctl restart apache2
systemctl is-active apache2
curl -I http://127.0.0.1
exit
poweroff
ip -br addr
cp /etc/network/interfaces /etc/network/interfaces.bak
cat /etc/network/interfaces 
vi /etc/network/interfaces 
cat /etc/network/interfaces 
poweroff
poweroff
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
fdisk /dev/sdc
fdisk /dev/sdc
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc /www_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
blkid /dev/sdc1 /dev/sdc2
cp /etc/fstab /etc/fstab.bak
vi /etc/fstab
vi /etc/fstab
mount -a
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
poweroff
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
df -h
ls -l /var/www/html
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.php /www_dir/
cp /var/www/html/logo.pnp /www_dir/
cp /var/www/html/logo.png /www_dir/
ls -l /www_dir
chown www-data:www-data /www_dir/index.php
chown www-data:www-data /www_dir/logo.png
chmod 644 /www_dir/index.php
chmod 644 /www_dir/logo.png
chmod 755 /www_dir
ls -l /www_dir
ls -ld /www_dir
cd /etc/apache2/sities-available
pwd
cd /etc/apache2/sites-available
pwd
ls -l 000-default.conf
cp 000-default.conf 000-default.conf.bak
ls -l 000-default.conf*
vi 000-default.conf
apache2ctl configtest
systemctl restart apache2
systemctl is-active apache2
curl -I http://127.0.0.1
cat /proc/partitions
cat /proc/partitions > /opt/particion
cat /opt/particion
ls -l /opt/particion 
poweroff
