#!/bin/bash

if [ "$1" = "-help" ]
then
    echo "Uso: backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo:"
    echo "backup_full.sh /var/log /backup_dir"
    echo "backup_full.sh /www_dir /backup_dir"
    exit 0
fi

if [ $# -ne 2 ]
then
    echo "Error: debe indicar origen y destino."
    echo "Use: backup_full.sh -help"
    exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO=$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz

if [ ! -d "$ORIGEN" ]
then
    echo "Error: el directorio origen no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]
then
    echo "Error: el directorio destino no existe."
    exit 1
fi

df "$ORIGEN" > /dev/null

if [ $? -ne 0 ]
then
    echo "Error: el sistema de archivos de origen no está disponible."
    exit 1
fi

df "$DESTINO" > /dev/null

if [ $? -ne 0 ]
then
    echo "Error: el sistema de archivos de destino no está disponible."
    exit 1
fi

tar -czf "$ARCHIVO" "$ORIGEN"

echo "Backup creado:"
echo "$ARCHIVO"
