#!/bin/bash

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

if [ "$1" = "-help" ]; then
    echo "Uso:"
    echo "./backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo:"
    echo "./backup_full.sh /www_dir /backup_dir"
    echo "./backup_full.sh /var/log /backup_dir"
else
    if [ -d "$ORIGEN" ]; then
        if [ -d "$DESTINO" ]; then

            if [ "$ORIGEN" = "/var/log" ]; then
                FILE=log_bkp_${FECHA}.tar.gz
            fi

            if [ "$ORIGEN" = "/www_dir" ]; then
                FILE=www_dir_bkp_${FECHA}.tar.gz
            fi

            if [ -z "$FILE" ]; then
                echo "Origen no valido. Use /var/log o /www_dir"
            else
                tar -cvzf "$DESTINO/$FILE" "$ORIGEN"
                echo "Backup realizado"
            fi

        else
            echo "El directorio de destino no existe"
        fi
    else
        echo "El directorio de origen no existe"
    fi
fi
